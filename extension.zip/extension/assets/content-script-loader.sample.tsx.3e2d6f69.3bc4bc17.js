(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/sample.tsx.3e2d6f69.js")
    );
  })().catch(console.error);

})();

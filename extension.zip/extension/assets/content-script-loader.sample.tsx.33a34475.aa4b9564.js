(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/sample.tsx.33a34475.js")
    );
  })().catch(console.error);

})();
